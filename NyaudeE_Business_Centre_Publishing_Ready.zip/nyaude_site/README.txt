NYAUDEE BUSINESS CENTRE
Publishing-ready static website.

Business:
- Products: Shoes and clothes
- WhatsApp: 0991478141
- Facebook: https://www.facebook.com/share/1FfSyo4Ppt/

To publish with GitHub Pages:
1. Create a GitHub repository named nyaudee-business-centre.
2. Upload index.html.
3. Open repository Settings > Pages.
4. Select Deploy from a branch, choose main and /root, then Save.
5. GitHub will provide the public website address.

Before launch, add individual product photos, sizes and prices as stock becomes available.
